const http=require('http');
const fs=require('fs');
const path=require('path');
const crypto=require('crypto');
const {WebSocketServer}=require('ws');
const PORT=Number(process.env.PORT)||8080;
const ROOT=__dirname;
const rooms=new Map();
const ALPH='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function code(){let s='';for(let i=0;i<6;i++)s+=ALPH[crypto.randomInt(ALPH.length)];return s}
function cleanCode(v){return String(v||'').toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,6)}
function send(ws,obj){if(ws.readyState===1)ws.send(JSON.stringify(obj))}
function safeFile(urlPath){
  let p=decodeURIComponent((urlPath||'/').split('?')[0]);if(p==='/'||!p)p='/index.html';
  const f=path.normalize(path.join(ROOT,p));return f.startsWith(ROOT)?f:null
}
const server=http.createServer((req,res)=>{
  const f=safeFile(req.url);if(!f)return res.writeHead(403).end('Forbidden');
  fs.stat(f,(err,st)=>{if(err||!st.isFile())return res.writeHead(404).end('Not found');
    const ext=path.extname(f).toLowerCase();const type={'.html':'text/html; charset=utf-8','.js':'application/javascript; charset=utf-8','.png':'image/png','.jpg':'image/jpeg','.css':'text/css'}[ext]||'application/octet-stream';
    res.writeHead(200,{'Content-Type':type,'Cache-Control':'no-cache'});fs.createReadStream(f).pipe(res)
  })
});
const wss=new WebSocketServer({server,path:'/ws'});
function leave(ws){
  const room=ws.room&&rooms.get(ws.room);if(!room)return;
  room.clients.delete(ws.id);if(room.host===ws){for(const c of room.clients.values())send(c,{type:'error',message:'Host closed the room.'});rooms.delete(ws.room)}else{for(const c of room.clients.values())send(c,{type:'peer-left',clientId:ws.id})}
  ws.room=''
}
wss.on('connection',ws=>{
  ws.id=crypto.randomUUID();ws.room='';ws.name='Player';send(ws,{type:'hello',clientId:ws.id});
  ws.on('message',raw=>{let m;try{m=JSON.parse(raw)}catch(e){return}
    if(m.type==='create-room'){
      leave(ws);let c=cleanCode(m.requestedCode);if(c.length!==6||rooms.has(c)){do{c=code()}while(rooms.has(c))}
      const room={host:ws,clients:new Map([[ws.id,ws]])};rooms.set(c,room);ws.room=c;ws.name=String(m.name||'Player').slice(0,20);send(ws,{type:'room-created',code:c});return
    }
    if(m.type==='join-room'){
      leave(ws);const c=cleanCode(m.code),room=rooms.get(c);if(!room){send(ws,{type:'error',message:'invalid room code, please try again.'});return}
      ws.room=c;ws.name=String(m.name||'Player').slice(0,20);room.clients.set(ws.id,ws);send(ws,{type:'joined',code:c});send(room.host,{type:'peer-joined',clientId:ws.id,name:ws.name});return
    }
    const room=ws.room&&rooms.get(ws.room);if(!room)return;
    if(m.type==='snapshot'&&ws===room.host){const target=room.clients.get(m.target);if(target)send(target,{type:'snapshot',snapshot:m.snapshot});return}
    if(m.type==='player-state'){for(const [id,c] of room.clients)if(c!==ws)send(c,{type:'player-state',clientId:ws.id,name:ws.name,state:m.state});return}
    if(m.type==='block-edit'){for(const c of room.clients.values())if(c!==ws)send(c,{type:'block-edit',clientId:ws.id,edit:m.edit});return}
  });
  ws.on('close',()=>leave(ws));
});
server.listen(PORT,()=>console.log(`Linecart multiplayer server: http://localhost:${PORT}`));
