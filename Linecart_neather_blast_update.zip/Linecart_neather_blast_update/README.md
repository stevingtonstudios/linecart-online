# Linecart Multiplayer — Dark Taiga Spawn + Bed Respawn Update

This ZIP is upload-ready: `index.html` is directly at the archive root.

## This build
- Keeps the real `js/multiplayer-client.js` and Node/WebSocket server files.
- Room Code remains an automatic six-character code and is server-confirmed for live sharing/joining.
- Saves, inventory, world edits, player position, progression, metadata, screenshots, seeds, and bed respawn data stay isolated to the world they belong to.
- Every newly-created world receives its own random seed and therefore its own generated terrain.
- Dark Taiga can now be the starting biome in a minority of worlds (about 14% of seeds), instead of being blocked from world spawn.
- Worlds that do not start in Dark Taiga still get a Dark Taiga reasonably close enough to discover while exploring.
- Dark Taiga grass is darker and colder green than ordinary grass.
- Dark Taiga spruce trees use the supplied dark leaf texture, dark bark side texture, and ringed spruce top texture.
- Dark spruce wood/leaves mine and drop as normal wood/leaves, so existing crafting remains compatible.
- A bed becomes the respawn point only when the player actually sleeps in it at night or during a thunderstorm.
- After elimination, the player respawns at the most recently slept-in bed in that world, as long as the bed still exists. If it is gone, respawn falls back to that world's original spawn.
- Bed respawn state is cleared when switching runtime worlds and restored only from the selected world's own save.
- Zombies use the uploaded proximity sound at randomized intervals when nearby.
- Mobs move somewhat faster, can drop down from trees/ledges, and larger drops cause small mob fall damage.

## Run real multiplayer
1. Install Node.js.
2. Run `npm install`.
3. Run `npm start`.
4. Open the local URL shown by the server.

A static-only host can load the game, but real room joining requires the included WebSocket server.

## Spruce planks + dual boats update
- Dark Taiga spruce trunks now support a dedicated Spruce Block item.
- 1 Spruce Block crafts into 4 Spruce Planks.
- 5 Oak Planks craft an Oak Boat; 5 Spruce Planks craft a darker Spruce Boat.
- Both boats can be placed only on water, entered with Use, steered on water, exited with Use, and saved per world with their wood type preserved.

## Spruce crafting + farther Dark Taiga update
- Oak Blocks and Spruce Blocks can both be used in the personal 2x2 grid to craft a Crafting Table; mixed oak/spruce also works.
- Personal crafting preserves the actual wood type when returning or dropping blocks.
- Dark Taiga no longer generates at the initial spawn or immediately beside it.
- A discoverable Dark Taiga anchor is generated roughly 82-140 blocks from world origin, with additional natural Dark Taiga generation only beyond the nearby spawn region.

## Fences, fence gates and sheep shearing update
- Oak Fence and Spruce Fence building pieces.
- Oak Fence Gate and Spruce Fence Gate can be opened and closed with Use.
- Crafting recipes: 4 planks + 2 sticks -> 3 fences; 2 planks + 4 sticks -> 1 fence gate.
- Shears are craftable from 2 Iron Ingots.
- Use Shears on a sheep to collect 1-3 wool and leave the sheep visibly sheared.
- A sheared sheep regrows its wool immediately after it has eaten grass twice; each grazing changes the grass block to dirt.


## Glass + Furnace Update
- Coal and charcoal can be used as furnace fuel.
- Oak/Spruce logs, planks, slabs, stairs, fences, gates and doors can also be used as wood fuel.
- Smelting Sand creates a transparent Glass Block using the supplied glass texture.
- 3 Glass Blocks craft into 9 thin Glass Windows, which can be placed in the world.

## Furnace textures, fuel balance and repaired multiplayer webclient
- Furnace now uses the supplied normal front texture, lit front texture, back/side texture, and top texture.
- The front changes to the lit texture while fuel is actively burning and switches back when the burn time ends.
- Furnace fuel values: Coal 8.0 s, Charcoal 8.0 s, Oak/Spruce Wood 1.5 s, Doors 1.15 s, Planks/Stairs/Gates 1.0 s, Fences 0.8 s, Slabs 0.65 s, Wooden tools 0.7 s, Sticks 0.35 s.
- Sand still smelts into Glass Block, and the glass/window system remains enabled.
- Spruce Wood can now also be smelted into Charcoal.
- `js/multiplayer-client.js` is restored and contains a six-character room-code generator, host/join controls, invite-link copying, player position syncing and block-edit syncing.
- `server.js` + `package.json` provide the matching HTTP/WebSocket room server. Run `npm install` and `npm start`, then open http://localhost:8080.
- On a static-only host, the game itself still loads but live multiplayer requires the included WebSocket server.

## Furnace asset packaging fix
- The four supplied furnace PNG files are included at the ZIP root byte-for-byte, without resizing, re-encoding or editing.
- The same exact images are also embedded in `index.html` only as a runtime fallback so the furnace no longer renders as a black cube when the game is opened directly from an extracted folder.
- Furnace face mapping: normal/lit front on the front face, supplied top texture on top, supplied back/side texture on the remaining faces.
