(()=>{
  'use strict';
  const $=id=>document.getElementById(id);
  const CODE_ALPHABET='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let ws=null, roomCode='', isHost=false, clientId='', connected=false, stateTimer=0;
  const status=msg=>{const e=$('multiStatus');if(e)e.textContent=msg};
  const normalizeCode=v=>String(v||'').toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,6);
  function randomCode(){
    const a=new Uint32Array(6);crypto.getRandomValues(a);
    return Array.from(a,n=>CODE_ALPHABET[n%CODE_ALPHABET.length]).join('');
  }
  function serverURL(){
    if(location.protocol==='http:')return 'ws://'+location.host+'/ws';
    if(location.protocol==='https:')return 'wss://'+location.host+'/ws';
    return 'ws://localhost:8080/ws';
  }
  function setRoom(code,pending=false){
    roomCode=normalizeCode(code)||randomCode();
    const el=$('multiRoomCode');if(el){el.textContent=roomCode;el.classList.toggle('pending',!!pending)}
    const share=$('multiShareCode');if(share)share.textContent=roomCode;
    const url=$('multiShareUrl');if(url){try{const u=new URL(location.href);u.searchParams.set('room',roomCode);url.value=u.href}catch(e){url.value='?room='+roomCode}}
  }
  function send(obj){if(ws?.readyState===WebSocket.OPEN){ws.send(JSON.stringify(obj));return true}return false}
  function connect(){
    if(ws&&ws.readyState<=1)return Promise.resolve();
    return new Promise((resolve,reject)=>{
      try{ws=new WebSocket(serverURL())}catch(e){reject(e);return}
      const timer=setTimeout(()=>{try{ws.close()}catch(e){};reject(new Error('Connection timeout'))},5000);
      ws.onopen=()=>{clearTimeout(timer);connected=true;status('Connected to Linecart multiplayer server.');resolve()};
      ws.onerror=()=>{};
      ws.onclose=()=>{connected=false;stopStateLoop();if(roomCode)status('Disconnected from multiplayer server. Start the included server and try again.')};
      ws.onmessage=ev=>{let m;try{m=JSON.parse(ev.data)}catch(e){return}handleMessage(m)};
    })
  }
  function playerName(){return ($('multiPlayerName')?.value||'Player').trim().slice(0,20)||'Player'}
  function handleMessage(m){
    const bridge=window.linecartMPBridge;
    if(m.type==='hello'){clientId=m.clientId||'';return}
    if(m.type==='room-created'){
      isHost=true;setRoom(m.code,false);status('Room '+roomCode+' is live. Share the code or invite link.');startStateLoop();return
    }
    if(m.type==='joined'){
      isHost=false;setRoom(m.code,false);status('Joined room '+roomCode+'. Loading shared world…');startStateLoop();return
    }
    if(m.type==='peer-joined'){
      status((m.name||'Player')+' joined room '+roomCode+'.');
      if(isHost){const snapshot=bridge?.getSnapshot?.();if(snapshot)send({type:'snapshot',target:m.clientId,snapshot})}
      return
    }
    if(m.type==='peer-left'){bridge?.removePeer?.(m.clientId);return}
    if(m.type==='snapshot'){if(m.snapshot&&bridge?.loadSnapshot?.(m.snapshot)){status('Shared world loaded.')}return}
    if(m.type==='player-state'){if(m.clientId!==clientId)bridge?.updatePeer?.(m.clientId,m.name||'Player',m.state);return}
    if(m.type==='block-edit'){bridge?.applyBlockEdit?.(m.edit);return}
    if(m.type==='error'){status('Error: '+(m.message||'multiplayer request failed'));return}
  }
  function startStateLoop(){
    stopStateLoop();stateTimer=setInterval(()=>{const state=window.linecartMPBridge?.getPlayerState?.();if(state)send({type:'player-state',state,name:playerName()})},100)
  }
  function stopStateLoop(){if(stateTimer){clearInterval(stateTimer);stateTimer=0}}
  async function host(){
    setRoom(roomCode||randomCode(),true);status('Creating room…');
    try{await connect();send({type:'create-room',requestedCode:roomCode,name:playerName()})}catch(e){status('Could not reach multiplayer server. Run npm start and try again.')}
  }
  async function join(){
    const code=normalizeCode($('multiJoinCode')?.value);if(code.length!==6){status('Error: invalid room code, please try again.');return}
    status('Checking room code…');
    try{await connect();send({type:'join-room',code,name:playerName()})}catch(e){status('Could not reach multiplayer server. Run npm start and try again.')}
  }
  async function copyInvite(){
    if(!roomCode)setRoom(randomCode(),true);
    const text=$('multiShareUrl')?.value||location.href;
    try{await navigator.clipboard.writeText(text);status('Invite link copied.')}catch(e){const inp=$('multiShareUrl');inp?.select?.();document.execCommand?.('copy');status('Invite link ready to copy.')}
  }
  function newCode(){setRoom(randomCode(),true);status('New room code generated. Press Host World to activate it.')}
  function showShare(){const p=$('multiSharePanel');if(p)p.style.display='block';copyInvite()}
  $('multiHost')?.addEventListener('click',host);
  $('multiJoin')?.addEventListener('click',join);
  $('multiNewCode')?.addEventListener('click',newCode);
  $('multiCopy')?.addEventListener('click',copyInvite);
  $('multiShare')?.addEventListener('click',showShare);
  $('multiShareCopyFallback')?.addEventListener('click',copyInvite);
  $('multiJoinCode')?.addEventListener('input',e=>{e.target.value=normalizeCode(e.target.value)});
  window.linecartRefreshInvite=()=>{
    try{const q=new URLSearchParams(location.search),r=normalizeCode(q.get('room'));if(r){$('multiJoinCode').value=r;setRoom(r,true)}else if(!roomCode)setRoom(randomCode(),true)}catch(e){if(!roomCode)setRoom(randomCode(),true)}
  };
  window.linecartMPClient={
    sendBlockEdit(edit){if(roomCode&&connected)send({type:'block-edit',edit})},
    isConnected:()=>connected,
    getRoomCode:()=>roomCode,
    generateRoomCode:newCode
  };
  window.linecartRefreshInvite();
})();
